<div class="modal fade" id="modalDetalheProduto" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="row">
				<div class="view overlay zoom col" style="margin:auto; margin-left:15px">
					<img src="http://rienco.com.au/wp-content/uploads/placeholder-image.jpg" class="img-fluid " alt="zoom">
					<div class="mask flex-center waves-effect waves-light">
					</div>
				</div>                              
				<div class="col">
				<!-- Card -->
					<div class="">
						<!-- Card content -->
						<div class="card-body text-center">
							<!-- Category & Title -->
							<a href="" class="text-muted">
								<h5>Fornecedor do Produto</h5>
							</a>
							<h4 class="card-title">
								<strong>
									<a href="">Título do produto</a>
								</strong>
							</h4>
							<!-- Description -->
							<p class="card-text" style="color:grey">
								Descrição do produto Descrição do produto Descrição do produto Descrição do produto 
							</p>
							<!-- Card footer -->
							<div class="px-1">
								<span class="float-center font-weight-bold" style="color:royalblue">
									<strong>R$1439</strong>
								</span>                                                  
							</div>
						</div>                                        
						<div class="container">
							<button class="btn btn-primary">Comprar</button>
						</div>
						<!-- Card content -->
					</div>
				<!-- Card -->
				</div>
			</div>
		</div>
	</div>
	</div>