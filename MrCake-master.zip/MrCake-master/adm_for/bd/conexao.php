<?php

    require_once $_SERVER['DOCUMENT_ROOT'] . "/bd/conexao.php";
	
?>