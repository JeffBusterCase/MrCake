<div class="tab-pane fade show active" id="pills-vendas" role="tabpanel" aria-labelledby="pills-home-tab">
	<div class="container" style="margin-top: 50px">
		<h2>Histórico de Vendas</h2>
			<table class="table table-striped">
				<thead>
					<tr>
						<th>Data da Compra</th>
						<th>Produto</th>
						<th>Cliente</th>
						<th>Valor</th>
						<th>Status</th>
					</tr>
				</thead>
				<tbody>
					
					
					
					<tr>
						 <td>01/10/2018</td>
						 <td>Bolo 1</td>
						 <td>Cliente 1</td>
						 <td>R$ 30,00</td>
						 <td>Entregue</td>
					</tr>
					<tr>
						 <td>06/10/2018</td>
						 <td>Bolo 2</td>
						 <td>Cliente 2</td>
						 <td>R$ 50,00</td>
						 <td>Entregue</td>
					</tr>
					<tr>
						 <td>12/11/2018</td>
						 <td>Bolo 3</td>
						 <td>Cliente 3</td>
						 <td>R$ 80,00</td>
						 <td>Aguardando aprovação</td>
					</tr>
			</tbody>
		</table>
	</div>
</div>