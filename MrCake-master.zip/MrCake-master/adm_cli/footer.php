<footer class="page-footer font-small unique-color-dark ">
	<div style="background-color: #c0264d; padding-top:10px; padding-bottom: 2px">
		<div class="container">
			<a href="Home.html">
				<img class="rounded" src="../Mr Cake Logo.png" width="auto" height="100" alt="Mr Cake Logo">
				<h4 class="h4-responsive">Mr. Cake - Estamos aqui para adoçar o seu dia</h4>
			</a>  
		</div>
	</div>
	<!-- Footer Links -->
		<div class="container text-center text-md-left mt-5">
			<!-- Grid row -->
			<div class="row mt-3">
				<!-- Grid column -->
					<div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
						<!-- Content -->
						<h6 class="text-uppercase font-weight-bold">Mr.Cake</h6>
						<hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto">
						<p>
							Descrição da empresa: blá blá blá blá blá blá blá
							blá blá blá blá blá blá blá 
							blá blá blá blá blá blá blá 
							blá blá blá blá blá blá blá.
						</p>
					</div>
				<!-- Grid column -->
				<div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
				<!-- Links -->
					<h6 class="text-uppercase font-weight-bold">Contact</h6>
					<hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto">
					<p>
						<i class="fa fa-home mr-3"></i> Rua Ficticia, 1924, São Paulo, SP
					</p>
					<p>
						<i class="fa fa-envelope mr-3"></i>marketing@mrcake.org.br
					</p>
					<p>
						<i class="fa fa-phone mr-3"></i> +55 11 5661-1665
					</p>
					<p>
						<i class="fa fa-print mr-3"></i> +55 11 5662-2665
					</p>
				</div>
				<!-- Grid column -->
			</div>
			<!-- Grid row -->
		</div>
	<!-- Footer Links -->
	<!-- Copyright -->
		<div class="footer-copyright text-center py-3">© 2018 Copyright:
			<a href=""> MrCake.ltda</a>
		</div>
	<!-- Copyright -->
</footer>