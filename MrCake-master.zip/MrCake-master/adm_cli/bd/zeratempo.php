<?php
	//$sql = "update usuarios set tempo = 0 where codigo = 2";
	//$stmt = sqlsrv_query( $conn, $sql );
	
?>