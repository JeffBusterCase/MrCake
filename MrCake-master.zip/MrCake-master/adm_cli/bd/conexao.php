<?php
    	// vou mudar aqui.

    require_once $_SERVER["DOCUMENT_ROOT"] . "/bd/conexao.php";
?>